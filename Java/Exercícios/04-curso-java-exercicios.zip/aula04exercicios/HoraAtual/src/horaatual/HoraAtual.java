package horaatual;

import java.util.Date;

public class HoraAtual {
    public static void main(String[] args) {
        Date relogio = new Date();
        System.out.print("Hora certa: ");
        System.out.println(relogio.toString());
    }  
}
